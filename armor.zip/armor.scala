
package boom

import Chisel._
import armor._

import cde.Parameters

//
// Call Convention:
// Return Register is x10, x11 (x10 for the first 8 bytes)
// Arguments are in x10 - x17
//
// Thus, Armor will track arguments in x10, x11:
//  - malloc(size) => x10 = size
//  - calloc(size, count) => x10 = size, x11 = count
//  - free(ptr) => x10 = ptr
//

//
// Range Cache has multiple operations:
//  1. Add new range (Memory allocation occured)
//  2. Clear a range (Deallocation occured)
//  3. Update an existing range (Reallocation occured)
//

class RangeCache(addr_width : Int, cache_size : Int, num_check : Int)(implicit p: Parameters) extends BoomModule()(p) {
    val io = new Bundle {
        val mem_addr = Vec(num_check, UInt(INPUT,addr_width))

        val operation = (UInt(INPUT, RangeCacheOperations.num_bits))
        val range_low = (UInt(INPUT, addr_width))
        val range_high = (UInt(INPUT, addr_width))
        val update_addr = (UInt(INPUT, addr_width))

        val hit = Vec(num_check, Bool(OUTPUT))
    }

    val ranges_low = Mem(cache_size, Bits(width=addr_width))
    val ranges_high = Mem(cache_size, Bits(width=addr_width))

    val ranges_hit = Wire(Vec(cache_size, Bool()))
    val ranges_mru = Reg(init = Vec(Seq.fill(cache_size)(false.B)))
    val ranges_valid = Reg(init = Vec(Seq.fill(cache_size)(false.B)))
    val ranges_to_be_invalid  = Wire(Vec(cache_size, Bool()))

    //
    // evict_index determines which range is next to be evicted from the table.
    // This will always be a range with its mru flag unset. update_index is the
    // entry index to use for update operations
    //

    val evict_index = Wire(UInt(width = log2Up(cache_size)))
    val update_index = Wire(UInt(width = log2Up(cache_size)))

    //
    // This determines if a range is added if the cache will be full. In this case,
    // all mru flags will be cleared.
    //

    val will_be_full = ((ranges_mru.asUInt() | (1.U << evict_index)) === 1.U)

    //
    // Perform operation based on what this module is told to do.
    //

    for (i <- 0 until cache_size) {
        ranges_to_be_invalid(i) := false.B
    }

    when (io.operation === RangeCacheOperations.add_range.U) {
        printf("Armor: Add Range: [0x%x, 0x%x]\n", io.range_low, io.range_high)
        ranges_low(evict_index) := io.range_low
        ranges_high(evict_index) := io.range_high
        ranges_valid(evict_index) := true.B
    }
    .elsewhen (io.operation === RangeCacheOperations.clear_range.U) {
        printf("Armor: Clear Range: [0x%x, 0x%x]\n", ranges_low(update_index), ranges_high(update_index))
        ranges_low(update_index) := 1.U
        ranges_high(update_index) := 0.U
        ranges_mru(update_index) := false.B
        ranges_valid(update_index) := false.B
        ranges_to_be_invalid(update_index) := true.B
    }
    .elsewhen (io.operation === RangeCacheOperations.update_range.U) {
        printf("Armor: Update Range: [0x%x, 0x%x]\n", io.range_low, io.range_high)
        ranges_low(update_index) := io.range_low
        ranges_high(update_index) := io.range_high
    }

    //
    // Compute hit flags and next mru_index.
    //

    for (i <- 0 until cache_size) {
        ranges_hit(i) := false.B
    }

    for (c <- 0 until num_check) {
        io.hit(c) := false.B

        for (i <- 0 until cache_size) {
            when ((io.mem_addr(c) >= ranges_low(i)) && (io.mem_addr(c) <= ranges_high(i)) && ranges_valid(i) && !ranges_to_be_invalid(i)) {
                printf("Range Cache Hit: address = 0x%x, range_low = 0x%x, range_high = 0x%x, range_valid = %x\n", io.mem_addr(c), ranges_low(i), ranges_high(i), ranges_valid(i))
                ranges_hit(i) := true.B
                ranges_mru(i) := true.B
                io.hit(c) := true.B
            }
        }
    }


    for (i <- 0 until cache_size) {
        when (ranges_low(i) === io.update_addr) {
            update_index := i.U
        }
    }

    //
    // Clear the mru flags if the module will end up full with the new range.
    //
    // N.B. This doesn't have to be separate from the above loop but it's better
    //      organized this way.
    //

    for (i <- 0 to cache_size-1) {
        when (!ranges_hit(i) && will_be_full && (io.operation === RangeCacheOperations.add_range.U)) {
            ranges_mru(i) := false.B
        }
    }
}

class MemoryChecker(addr_width : Int, cache_size : Int, num_check : Int)(implicit p: Parameters) extends BoomModule()(p) {
    val io = new Bundle {
        val csrs = (new MemoryCheckerCsrs(addr_width)).asInput

        val mem_check = Vec(num_check, Bool(INPUT))
        val mem_addr = Vec(num_check, UInt(INPUT,addr_width))

        val cache_operation = (UInt(INPUT,2))
        val cache_range_low = (UInt(INPUT,addr_width))
        val cache_range_high = (UInt(INPUT,addr_width))
        val cache_update_addr = (UInt(INPUT,addr_width))

        val stack_pointer = Vec(num_check, UInt(INPUT,addr_width))

        val alarm = Vec(num_check, Bool(OUTPUT))
    }

    val range_cache = Module(new RangeCache(addr_width, cache_size, num_check))
    range_cache.io.mem_addr := io.mem_addr
    range_cache.io.operation := io.cache_operation
    range_cache.io.range_low := io.cache_range_low
    range_cache.io.range_high := io.cache_range_high
    range_cache.io.update_addr := io.cache_update_addr

    def ValidateAddress(mem_addr : UInt, mem_check : Bool, stack_pointer : UInt) = {
        val text_filtered = (mem_addr >= io.csrs.text_start) && (mem_addr <= io.csrs.text_end)
        val data_filtered = (mem_addr >= io.csrs.data_start) && (mem_addr <= io.csrs.bss_end)
        val stack_filtered = (mem_addr >= stack_pointer) && (mem_addr <= io.csrs.stack_base)

        val addr_filtered = text_filtered || data_filtered || stack_filtered
        val mem_addr_valid = (!addr_filtered) && mem_check

        when (text_filtered && mem_check) {
            printf(".text filtered 0x%x (text_start = 0x%x, text_end = 0x%x)\n", mem_addr, io.csrs.text_start, io.csrs.text_end)
        }

        when (data_filtered && mem_check) {
            printf(".data filtered 0x%x (data_start = 0x%x, bss_end = 0x%x)\n", mem_addr, io.csrs.data_start, io.csrs.bss_end)
        }

        when (stack_filtered && mem_check) {
            printf(".stack filtered 0x%x (sp = 0x%x, stack_base = 0x%x)\n", mem_addr, stack_pointer, io.csrs.stack_base)
        }

        mem_addr_valid
    }

    for (c <- 0 until num_check) {
        val mem_addr_valid = ValidateAddress(io.mem_addr(c), io.mem_check(c), io.stack_pointer(c))
        io.alarm(c) := mem_addr_valid && (!range_cache.io.hit(c))
    }
}

class AllocationChecker(addr_width : Int, commit_width : Int)(implicit p: Parameters) extends  BoomModule()(p) {
    val io = new Bundle {
        val csrs = (new AllocationCheckerCsrs(addr_width)).asInput

        val com_valids = Wire(Vec(commit_width, Bool())).asInput
        val com_uops = Wire(Vec(commit_width, new MicroOp())).asInput

        val ret_addr = Vec(commit_width, UInt(width = addr_width)).asInput
        val arg0 = Vec(commit_width, UInt(width = addr_width)).asInput
        val arg1 = Vec(commit_width, UInt(width = addr_width)).asInput
        val ret = Vec(commit_width, UInt(width = addr_width)).asInput

        val cache_operation = (UInt(OUTPUT,RangeCacheOperations.num_bits))
        val cache_range_low = (UInt(OUTPUT,addr_width))
        val cache_range_high = (UInt(OUTPUT,addr_width))
        val cache_update_addr = (UInt(OUTPUT,addr_width))
    }

    val cache_operation = Wire(UInt(RangeCacheOperations.num_bits))
    val cur_func_id = Wire(UInt(AllocationFunctionIds.num_bits))
    val latched_func_id = Reg(UInt(AllocationFunctionIds.num_bits))
    val func_start_hit = Wire(Vec(AllocationFunctionIds.num_funcs, Bool()))
    val func_end_hit = Wire(Vec(AllocationFunctionIds.num_funcs, Bool()))
    val ret_addr_latched = Reg(init = ~UInt(0, addr_width))
    val start_commit_slot = Wire(UInt(log2Up(commit_width)))
    val ret_commit_slot = Wire(UInt(log2Up(commit_width)))

    cur_func_id := PriorityEncoder(func_start_hit)

    //
    // Compute flags telling whether the start or end of each function
    // in the table is hit. This module assumes a consistent state for
    // the function table, meaning there are aren't mismatched addresses, 
    // etc...
    //

    for (i <- 0 until AllocationFunctionIds.num_funcs) {
        func_start_hit(i) := false.B

        for (w <- 0 until commit_width) {
            when ((io.com_uops(w).pc === io.csrs.func_start_addrs(i)) && io.com_valids(w)) {
                func_start_hit(i) := true.B
                start_commit_slot := w.U
            }
        }
    }

    for (i <- 0 until AllocationFunctionIds.num_funcs) {
        func_end_hit(i) := false.B

        for (w <- 0 until commit_width) {
            when ((io.com_uops(w).pc === ret_addr_latched) && io.com_valids(w)) {
                func_end_hit(i) := true.B
                ret_commit_slot := w.U
            }
        }
    }

    val arg0_latched = Reg(UInt(width = addr_width))
    val arg1_latched = Reg(UInt(width = addr_width))

    val ret_value = io.ret(ret_commit_slot)

    //
    // For all functions, arg0 and arg1 are always recorded on the
    // start of the function.
    //

    when (func_start_hit.asUInt() != 0.U) {
        printf("Armor: Start capture on funcid = %d. Commit slot = %d, arg0 = 0x%x, arg1 = 0x%x, Ret addr = 0x%x\n", cur_func_id, start_commit_slot, io.arg0(start_commit_slot), io.arg1(start_commit_slot), io.ret_addr(0))
        arg0_latched := io.arg0(start_commit_slot)
        arg1_latched := io.arg1(start_commit_slot)
        latched_func_id := cur_func_id
        ret_addr_latched := io.ret_addr(start_commit_slot)
    }

    //
    // Compute range bounds and output a cache operation depending on
    // what function just completed.
    //

    when (func_end_hit.asUInt() != 0.U) {
        printf("Armor: End capture on funcid = %d. Commit slot = %d, arg0 = 0x%x, arg1 = 0x%x, Ret val = 0x%x\n", latched_func_id, ret_commit_slot, arg0_latched, arg1_latched, ret_value)
        when (latched_func_id === AllocationFunctionIds.malloc.U) {
            // range_low = malloc(length)
            // range_high = range_low + length
            cache_operation := RangeCacheOperations.add_range.U
            io.cache_range_low := ret_value
            io.cache_range_high := ret_value + arg0_latched
        }
        .elsewhen (latched_func_id === AllocationFunctionIds.calloc.U) {
            // range_low = calloc(count, size)
            // range_high = range_low + count * size
            cache_operation := RangeCacheOperations.add_range.U
            io.cache_range_low := ret_value
            io.cache_range_high := ret_value + arg0_latched * arg1_latched
        }
        .elsewhen (latched_func_id === AllocationFunctionIds.realloc.U) {
            // range_low = realloc(orig_low, new_length)
            // range_high = range_low + new_length
            cache_operation := RangeCacheOperations.update_range.U
            io.cache_range_low := ret_value
            io.cache_range_high := ret_value + arg1_latched
            io.cache_update_addr := arg0_latched
        }
        .elsewhen (latched_func_id === AllocationFunctionIds.free.U) {
            cache_operation := RangeCacheOperations.clear_range.U
            io.cache_update_addr := arg0_latched
        }
        .elsewhen (latched_func_id === AllocationFunctionIds.mmap.U) {
            cache_operation := RangeCacheOperations.add_range.U
            io.cache_range_low := ret_value
            io.cache_range_high := ret_value + arg1_latched
        }
        .elsewhen (latched_func_id === AllocationFunctionIds.munmap.U) {
            cache_operation := RangeCacheOperations.clear_range.U
            io.cache_update_addr := arg0_latched
        }

        ret_addr_latched := ~UInt(0, addr_width)

        when ((ret_value != 0.U) || (latched_func_id === AllocationFunctionIds.free.U) || (latched_func_id === AllocationFunctionIds.munmap.U)) {
            io.cache_operation := cache_operation
        }
        .otherwise {
            io.cache_operation := RangeCacheOperations.noop.U
        }
    }
    .otherwise {
        io.cache_operation := RangeCacheOperations.noop.U
    }
}


